package com.jleon.openweatherapp;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.jleon.openweatherapp.api.GooglePlacesApi;
import com.jleon.openweatherapp.model.prediction.Prediction;
import com.jleon.openweatherapp.model.prediction.PredictionResult;
import com.jleon.openweatherapp.service.ServiceGeneratorGooglePlaces;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by jleon on 20/02/2018.
 */

public class GooglePlacesResultAdapter extends BaseAdapter implements Filterable{

    private Context mContext;
    private List<Prediction> resultList = new ArrayList<Prediction>();

    public GooglePlacesResultAdapter(Context _context) {
        this.mContext = _context;
    }

    @Override
    public int getCount() {
        return resultList.size();
    }

    @Override
    public Prediction getItem(int i) {
        return resultList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            // Inflamos el Layout
            LayoutInflater inflater = (LayoutInflater) mContext
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(android.R.layout.simple_dropdown_item_1line, viewGroup, false);
        }

        //Obtenemos la referencia al TextView
        TextView text = view.findViewById(android.R.id.text1);
        //Obtenemos el elemento i-ésimo
        Prediction p = getItem(i);
        //Setteamos el texto
        text.setText(p.getDescription());

        return view;
    }

    //@Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                FilterResults filterResults = new FilterResults();
                if (charSequence != null) {
                    //Realizamos la búsqueda
                    List<Prediction> resultados = findCities(charSequence);
                    //Si tenemos resultados, los añadimos
                    if (resultados != null) {
                        filterResults.values = resultados;
                        filterResults.count = resultados.size();
                    }
                    //Si no, devolvemos un conjunto vacío de resultados
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                if (filterResults != null && filterResults.count > 0) {
                    resultList = (List<Prediction>) filterResults.values;
                    notifyDataSetChanged();
                } else {
                    notifyDataSetInvalidated();
                }
            }
        };
    }

    private List<Prediction> findCities(CharSequence text) {
        List<Prediction> result = null;

        //Generar el servicio
        GooglePlacesApi api = ServiceGeneratorGooglePlaces.createService(GooglePlacesApi.class);
        //Obtener la petición
        Call<PredictionResult> call = api.autoComplete(text.toString());

        //call.enqueue();

        try {
            Response<PredictionResult> response = call.execute();
            if (response.isSuccessful()) {
                if ("OK".equalsIgnoreCase(response.body().getStatus()))
                    result = response.body().getPredictions();
            }

            //TODO Manejo de errores
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;

    }

}
