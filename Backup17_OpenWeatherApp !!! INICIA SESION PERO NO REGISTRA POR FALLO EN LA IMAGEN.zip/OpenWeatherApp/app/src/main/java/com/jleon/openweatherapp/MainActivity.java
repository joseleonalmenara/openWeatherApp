package com.jleon.openweatherapp;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.jleon.openweatherapp.model.BlurTransformation;

import com.squareup.picasso.Picasso;


public class MainActivity extends AppCompatActivity implements OnCityChanged, WeatherFragment.OnFragmentInteractionListener{

    ImageView fondo;
    TextView localizacion;
    Fragment f = null;
    private Double lat, lng;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {


        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            FragmentManager fM = getSupportFragmentManager();
            FragmentTransaction transaction = fM.beginTransaction();
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    transaction.replace(R.id.contenedor, new WeatherFragment()).commit();
                    return true;
                case R.id.navigation_dashboard:
                    transaction.replace(R.id.contenedor, ForecastFragment.newInstance(lat, lng)).commit();
                    return true;
                case R.id.navigation_notifications:
                    Toast.makeText(MainActivity.this, "Fragment no implementado aún", Toast.LENGTH_SHORT).show();
                    return true;
            }

            if(f!=null) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.contenedor, f)
                        .commit();
            }

            return true;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        fondo = findViewById(R.id.fondo);
        localizacion = findViewById(R.id.textViewLocalizacion);

        Picasso
                .with(getApplicationContext())
                .load("https://png.pngtree.com/thumb_back/fw800/back_pic/03/56/99/53579f5dbbcaf28.jpg")
                .transform(new BlurTransformation(getApplicationContext()))
                .fit()
                .into(fondo);


        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.contenedor, new WeatherFragment())
                .commit();


        //Por defecto asignamos la latitud y la longitud de Sevilla, Si iniciamos las variables
        // A 0, se mostraría información del Ecuador
        //lat = 0.0;
        //lng = 0.0;

        lat = 37.3914105;
        lng = -5.9591776;

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    public void iniciarSesion(MenuItem item) {
        Intent i = new Intent(this, LoginActivity.class);
        startActivity(i);
    }

    @Override
    public void actualizaCoordenadas(Double lat, Double lng) {
        this.lat = lat;
        this.lng = lng;
        //forecast.refreshContent(lat,lng);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}