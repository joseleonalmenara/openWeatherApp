package com.jleon.openweatherapp;

/**
 * Created by jleon on 02/03/2018.
 */

public class ResponseAuth {
    private String token;
    private String displayName;
    private String email;
    private String avatar;

    public ResponseAuth() {
    }

    public ResponseAuth(String token, String displayName, String email, String avatar) {
        this.token = token;
        this.displayName = displayName;
        this.email = email;
        this.avatar = avatar;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    @Override
    public String toString() {
        return "ResponseAuth{" +
                "token='" + token + '\'' +
                ", displayName='" + displayName + '\'' +
                ", email='" + email + '\'' +
                ", avatar='" + avatar + '\'' +
                '}';
    }
}