package com.jleon.openweatherapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.jleon.openweatherapp.api.DamWeatherApi;
import com.jleon.openweatherapp.service.ServiceGeneratorDamWeather;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RegistroActivity extends AppCompatActivity {
    EditText nombre, email, password, photo;
    Button registro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        nombre = findViewById(R.id.editTextNombreUsuario);
        email = findViewById(R.id.editTextEmailUsuario);
        password = findViewById(R.id.editTextPasswordUsuario);
        photo = findViewById(R.id.editTextPhoto);
        registro = findViewById(R.id.buttonRegistrarse);

//        KeeperApi keeperApi = ServiceGenerator.createService(KeeperApi.class);
//
//        final Call<ResponseAuth> peticionRegistro = keeperApi.doRegistro(nombre.toString(), email.toString(), password.toString());

        /*
        peticionRegistro.enqueue(new Callback<ResponseAuth>() {
            @Override
            public void onResponse(Call<ResponseAuth> call, Response<ResponseAuth> response) {
                ResponseAuth responseAuth = response.body();
                Intent i = new Intent(RegistroActivity.this, MainActivity.class);
                i.putExtra("key", responseAuth.getKey());
                i.putExtra("nombre", responseAuth.getNombre());
                i.putExtra("email", responseAuth.getEmail());
                i.putExtra("mensaje", responseAuth.getMensaje());
                startActivity(i);
            }

            @Override
            public void onFailure(Call<ResponseAuth> call, Throwable t) {
                Toast.makeText(RegistroActivity.this, "Ha ocurrido un error de red", Toast.LENGTH_SHORT).show();
            }
        });
        */

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent i = new Intent(RegistroActivity.this, MainActivity.class);
                //startActivity(i);

                DamWeatherApi damWeatherApi = ServiceGeneratorDamWeather.createService(DamWeatherApi.class);

                final Call<ResponseAuth> peticionRegistro = damWeatherApi.doRegister(nombre.getText().toString(), email.getText().toString(), password.getText().toString(), photo.getText().toString());

                peticionRegistro.enqueue(new Callback<ResponseAuth>() {
                    @Override
                    public void onResponse(Call<ResponseAuth> call, Response<ResponseAuth> response) {
                        if (response.isSuccessful()) {
                            ResponseAuth responseAuth = response.body();
                            Intent i = new Intent(RegistroActivity.this, MainActivity.class);
                            i.putExtra("token", responseAuth.getToken());
                            i.putExtra("displayName", responseAuth.getDisplayName());
                            i.putExtra("email", responseAuth.getEmail());
                            i.putExtra("avatar", responseAuth.getAvatar());
                            Log.i("registro", responseAuth.toString());
                            startActivity(i);
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseAuth> call, Throwable t) {
                        Toast.makeText(RegistroActivity.this, "Ha ocurrido un error de red", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}