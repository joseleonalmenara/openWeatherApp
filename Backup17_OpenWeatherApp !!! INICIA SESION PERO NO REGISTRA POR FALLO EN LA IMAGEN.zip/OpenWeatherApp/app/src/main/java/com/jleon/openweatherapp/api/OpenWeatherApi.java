package com.jleon.openweatherapp.api;



import com.jleon.openweatherapp.model.Forecast.ForecastInfo;
import com.jleon.openweatherapp.model.Weather.WeatherInfo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by jleon on 14/02/2018.
 */

public interface OpenWeatherApi {

    @GET("/data/2.5/weather")
    Call<WeatherInfo> getWeatherInfoByCity(@Query("q") String city);

    @GET("/data/2.5/weather")
    Call<WeatherInfo> getWeatherInfoByCoords(@Query("lat") Double lat, @Query("lon") Double lon);

    @GET("/data/2.5/forecast")
    Call<ForecastInfo> getForecastInfoByCity(@Query("q") String city);

    @GET("/data/2.5/forecast")
    Call<ForecastInfo> getForecastInfoByCoords(@Query("lat") Double lat, @Query("lon") Double lon);

}