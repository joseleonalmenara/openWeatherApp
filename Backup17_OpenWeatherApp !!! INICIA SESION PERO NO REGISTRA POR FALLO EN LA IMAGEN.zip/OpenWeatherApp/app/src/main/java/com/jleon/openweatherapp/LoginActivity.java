package com.jleon.openweatherapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.jleon.openweatherapp.api.DamWeatherApi;
import com.jleon.openweatherapp.model.BlurTransformation;
import com.jleon.openweatherapp.service.ServiceGeneratorDamWeather;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    EditText email, pass;
    Button login;
    TextView registro;
    ImageView fondo;
    private ResponseAuth responseAuth;
    private Call<ResponseAuth> peticionLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.textViewEmail);
        pass = findViewById(R.id.textViewPassword);
        login = findViewById(R.id.login);
        registro = findViewById(R.id.textViewAccederRegistro);
        fondo = findViewById(R.id.fondo);



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent i = new Intent(LoginActivity.this, MainActivity.class);
                //startActivity(i);

                DamWeatherApi damWeatherApi = ServiceGeneratorDamWeather.createService(DamWeatherApi.class);

                peticionLogin = damWeatherApi.doLogin(email.getText().toString(), pass.getText().toString());

                peticionLogin.enqueue(new Callback<ResponseAuth>() {
                    @Override
                    public void onResponse(Call<ResponseAuth> call, Response<ResponseAuth> response) {
                        if (response.isSuccessful()) {
                            responseAuth = response.body();
                            Intent i = new Intent(LoginActivity.this, MainActivity.class);

                            Bundle bundle = new Bundle();
                            bundle.putString("token", responseAuth.getToken());
                            bundle.putString("email", responseAuth.getEmail());
                            bundle.putString("password", responseAuth.getEmail());
                            bundle.putString("displayName", responseAuth.getDisplayName());
                            i.putExtras(bundle);
                            Log.i("loggin", responseAuth.toString());
                            startActivity(i);
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseAuth> call, Throwable t) {
                        Toast.makeText(LoginActivity.this, "Error de red", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, RegistroActivity.class);
                startActivity(i);
            }
        });

        Picasso
                .with(getApplicationContext())
                .load("https://png.pngtree.com/thumb_back/fw800/back_pic/03/56/99/53579f5dbbcaf28.jpg")
                .transform(new BlurTransformation(getApplicationContext()))
                .fit()
                .into(fondo);

    }

    }

