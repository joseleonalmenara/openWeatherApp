package com.jleon.openweatherapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import com.jleon.openweatherapp.api.GooglePlacesApi;
import com.jleon.openweatherapp.api.OpenWeatherApi;
import com.jleon.openweatherapp.model.DelayAutoCompleteTextView;
import com.jleon.openweatherapp.model.Weather.WeatherInfo;
import com.jleon.openweatherapp.model.details.DetailsResult;
import com.jleon.openweatherapp.model.prediction.Prediction;
import com.jleon.openweatherapp.service.ServiceGenerator;
import com.jleon.openweatherapp.service.ServiceGeneratorGooglePlaces;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link WeatherFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link WeatherFragment#newInstance} factory method to
 * create an instance of this fragment.
 */

public class WeatherFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    DelayAutoCompleteTextView autoCompleteTextView;
    ImageView img;
    TextView textLatLng;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private TextView weatherDescription, weatherTemp, weatherMin, weatherMax, localizacion;
    private ImageView weatherIcon;
    Double lat, lng;
    private OnCityChanged mListener;

    public WeatherFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static WeatherFragment newInstance(/*String param1, String param2*/) {
        WeatherFragment fragment = new WeatherFragment();
        /*Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);*/
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1, String.valueOf(lat));
            mParam2 = getArguments().getString(ARG_PARAM2, String.valueOf(lng));
        }


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_weather, container, false);

        textLatLng = view.findViewById(R.id.textViewLatLong);
        //Instancia de la imagen para mostrar la ciudad que buscamos

        autoCompleteTextView = view.findViewById(R.id.autoCompleteTextView);
        autoCompleteTextView.setAdapter(new GooglePlacesResultAdapter(getContext()));

        weatherDescription = view.findViewById(R.id.textViewDescripcion);
        weatherTemp = view.findViewById(R.id.textViewTemp);
        weatherMax = view.findViewById(R.id.textViewTempMax);
        weatherMin = view.findViewById(R.id.textViewTempMin);
        weatherIcon = view.findViewById(R.id.imageViewIconoTiempo);
        localizacion = view.findViewById(R.id.textViewLocalizacion);


        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, final View view, int i, long l) {

                final GooglePlacesApi googlePlacesApi = ServiceGeneratorGooglePlaces.createService(GooglePlacesApi.class);

                Prediction p = (Prediction) autoCompleteTextView.getAdapter().getItem(i);

                final Call<DetailsResult> callGoogle =  googlePlacesApi.getPlaceDetails(p.getPlace_id());

                getFragmentManager().beginTransaction().detach(WeatherFragment.this).attach(WeatherFragment.this).commit();

                //1ª versión
                callGoogle.enqueue(new Callback<DetailsResult>() {
                    @Override
                    public void onResponse(Call<DetailsResult> call, Response<DetailsResult> response) {
                        if (response.isSuccessful()) {
                            DetailsResult result = response.body();
                            textLatLng.setText(String.format("%f, %f",
                                    result.getResult().getGeometry().getLocation().getLat(),
                                    result.getResult().getGeometry().getLocation().getLng()));


                            //Preparamos la segunda petición
                            final OpenWeatherApi openWeatherApi = ServiceGenerator.createService(OpenWeatherApi.class);


                            //Llamada a una ciudad concreta
                            //Call<WeatherInfo> callWeather = openWeatherApi.getWeatherInfoByCity("Sevilla");

                            //Llamada a una localización a partir de las coordenadas
                            Call<WeatherInfo> callWeather = openWeatherApi.getWeatherInfoByCoords(
                                    lat = result.getResult().getGeometry().getLocation().getLat(),
                                    lng = result.getResult().getGeometry().getLocation().getLng()
                            );



                            callWeather.enqueue(new Callback<WeatherInfo>() {
                                @Override
                                public void onResponse(Call<WeatherInfo> call, Response<WeatherInfo> response) {
                                    if (response.isSuccessful()) {
                                        //Rescatamos los datos de la respuesta
                                        WeatherInfo weatherInfo = response.body();
                                        //Aquí "dibujamos" todos los datos en la interfaz de usuario
                                        weatherDescription.setText(weatherInfo.getWeather().get(0).getDescription());
                                        weatherTemp.setText(Math.round(weatherInfo.getMain().getTemp()) + " º");
                                        weatherMax.setText(Math.round(weatherInfo.getMain().getTempMax()) + " º max.");
                                        weatherMin.setText(Math.round(weatherInfo.getMain().getTempMin()) + " º min.");
                                        textLatLng.setText("");
                                        localizacion.setText(autoCompleteTextView.getText().toString());
                                        //weatherIcon.setImageURI(Uri.parse("http://openweathermap.org/img/w/" + weatherInfo.getWeather().get(0).getIcon() + ".png"));
                                        Picasso.with(getContext()).load("http://openweathermap.org/img/w/" + weatherInfo.getWeather().get(0).getIcon() + ".png").into(weatherIcon);
                                        Log.i("Retrofit Weather OK", weatherInfo.toString());


                                        mListener.actualizaCoordenadas(lat, lng);


                                    } else {
                                        //Toast.makeText(MainActivity.this, "Lo sentimos, pero ocurrió algún error", Toast.LENGTH_SHORT).show();
                                    }

                                }

                                @Override
                                public void onFailure(Call<WeatherInfo> call, Throwable t) {
                                    //Toast.makeText(MainActivity.this, "Lo sentimos, pero ocurrió algun error de red", Toast.LENGTH_SHORT).show();
                                    Log.e("Fallo", t.getMessage());
                                }
                            });

                            autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> adapterView, final View view, int i, long l) {

                                    //final GooglePlacesApi googlePlacesApi = ServiceGeneratorGooglePlaces.createService(GooglePlacesApi.class);

                                    Prediction p = (Prediction) autoCompleteTextView.getAdapter().getItem(i);

                                    final Call<DetailsResult> callGoogle =  googlePlacesApi.getPlaceDetails(p.getPlace_id());

                                    getFragmentManager().beginTransaction().detach(WeatherFragment.this).attach(WeatherFragment.this).commit();

                                    //1ª versión
                                    callGoogle.enqueue(new Callback<DetailsResult>() {
                                        @Override
                                        public void onResponse(Call<DetailsResult> call, Response<DetailsResult> response) {
                                            if (response.isSuccessful()) {
                                                DetailsResult result = response.body();
                                                textLatLng.setText(String.format("%f, %f",
                                                        result.getResult().getGeometry().getLocation().getLat(),
                                                        result.getResult().getGeometry().getLocation().getLng()));

                                                lat = result.getResult().getGeometry().getLocation().getLat();
                                                lng = result.getResult().getGeometry().getLocation().getLng();


                                                /*if (result.getResult().getPhotos() != null) {
                                                    if (!result.getResult().getPhotos().isEmpty()) {
                                                        String photo_url = String.format("https://maps.googleapis.com/maps/api/place/photo?maxwidth=1000&key=AIzaSyD_FMG1EnTUm3Ja7bSnlCV2VINLFq7rLMw&photoreference=%s", result.getResult().getPhotos().get(0).getPhoto_reference());
                                                        Picasso
                                                                .with(getContext())
                                                                .load(photo_url)
                                                                .into(img);
                                                    }

                                                }*/

                                                mListener.actualizaCoordenadas(lat, lng);



                                                //Preparamos la segunda petición
                                                //OpenWeatherApi openWeatherApi = ServiceGeneratorOpenWeather.createService(OpenWeatherApi.class);


                                                //Llamada a una ciudad concreta
                                                //Call<WeatherInfo> callWeather = openWeatherApi.getWeatherInfoByCity("Sevilla");

                                                //Llamada a una localización a partir de las coordenadas
                                                Call<WeatherInfo> callWeather = openWeatherApi.getWeatherInfoByCoords(
                                                        lat,
                                                        lng
                                                );



                                                callWeather.enqueue(new Callback<WeatherInfo>() {
                                                    @Override
                                                    public void onResponse(Call<WeatherInfo> call, Response<WeatherInfo> response) {
                                                        if (response.isSuccessful()) {
                                                            //Rescatamos los datos de la respuesta
                                                            WeatherInfo weatherInfo = response.body();
                                                            //Aquí "dibujamos" todos los datos en la interfaz de usuario
                                                            weatherDescription.setText(weatherInfo.getWeather().get(0).getDescription());
                                                            weatherTemp.setText(Math.round(weatherInfo.getMain().getTemp()) + " º");
                                                            weatherMax.setText(Math.round(weatherInfo.getMain().getTempMax()) + " º max.");
                                                            weatherMin.setText(Math.round(weatherInfo.getMain().getTempMin()) + " º min.");
                                                            //weatherCiudad.setText(weatherInfo.getName());
                                                            Picasso.with(getContext()).load("http://openweathermap.org/img/w/" + weatherInfo.getWeather().get(0).getIcon() + ".png").into(weatherIcon);
                                                            Log.i("Retrofit Weather OK", weatherInfo.toString());




                                                        } else {
                                                            //Toast.makeText(MainActivity.this, "Lo sentimos, pero ocurrió algún error", Toast.LENGTH_SHORT).show();
                                                        }
                                                    }

                                                    @Override
                                                    public void onFailure(Call<WeatherInfo> call, Throwable t) {
                                                        //Toast.makeText(MainActivity.this, "Lo sentimos, pero ocurrió algun error de red", Toast.LENGTH_SHORT).show();
                                                        Log.e("Fallo", t.getMessage());
                                                    }
                                                });


                                            }
                                        }

                                        @Override
                                        public void onFailure(Call<DetailsResult> call, Throwable t) {

                                        }
                                    });





                                }
                            });


                        }
                    }

                    @Override
                    public void onFailure(Call<DetailsResult> call, Throwable t) {

                    }
                });





            }
        });






        return view;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnCityChanged) {
            mListener = (OnCityChanged) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);

    }


}
