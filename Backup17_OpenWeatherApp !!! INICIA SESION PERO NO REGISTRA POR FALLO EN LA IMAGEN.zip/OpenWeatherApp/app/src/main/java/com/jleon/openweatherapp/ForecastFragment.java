package com.jleon.openweatherapp;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import com.jleon.openweatherapp.api.OpenWeatherApi;
import com.jleon.openweatherapp.model.Forecast.ForecastInfo;
import com.jleon.openweatherapp.service.ServiceGenerator;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {@link OnListFragmentInteractionListener}
 * interface.
 */
public class ForecastFragment extends Fragment {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;
    private OnListFragmentInteractionListener mListener;
    private ForecastInfo forecastInfoList;
    MyForecastRecyclerViewAdapter adapter;

    public static final String LATITUD = "LAT";
    public static final String LONGITUD = "LNG";

    private Double mParam1;
    private Double mParam2;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public ForecastFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static ForecastFragment newInstance(Double lat, Double lng) {
        ForecastFragment fragment = new ForecastFragment();
        Bundle args = new Bundle();
        args.putDouble(LATITUD, lat);
        args.putDouble(LONGITUD, lng);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getDouble(LATITUD);
            mParam2 = getArguments().getDouble(LONGITUD);
        }
    }

    public void refreshContent(Double v1, Double v2) {
        mParam1 = v1;
        mParam2 = v2;
        //
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_forecast_list, container, false);

        refreshContent(mParam1, mParam2);

        //forecastInfoList = new ArrayList<>();

        final RecyclerView recyclerView = (RecyclerView) view;

        //Double lat = 37.39;
        //Double lon = -6.0;

        OpenWeatherApi openWeatherApi = ServiceGenerator.createService(OpenWeatherApi.class);

        //Call<ForecastInfo> peticionForecast = openWeatherApi.getForecastInfoByCoords(lat, lon);
        Call<ForecastInfo> peticionForecast = openWeatherApi.getForecastInfoByCoords(mParam1, mParam2);

        peticionForecast.enqueue(new Callback<ForecastInfo>() {
            @Override
            public void onResponse(Call<ForecastInfo> call, Response<ForecastInfo> response) {
                if (response.isSuccessful()) {
                    forecastInfoList = response.body();

                    adapter = new MyForecastRecyclerViewAdapter(getActivity(), forecastInfoList.getForecastItem());
                    recyclerView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<ForecastInfo> call, Throwable t) {
                Log.e("Fallo", t.getMessage());
                //Toast.makeText(getContext(), "Ha ocurrido un error de red", Toast.LENGTH_SHORT).show();
            }
        });

        // Set the adapter
        if (view instanceof RecyclerView) {
            Context context = view.getContext();
            //RecyclerView recyclerView = (RecyclerView) view;
            if (mColumnCount <= 1) {
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
            } else {
                recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
            }
            //adapter = new MyForecastRecyclerViewAdapter(getActivity(), forecastInfoList);
            //recyclerView.setAdapter(adapter);
        }
        return view;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        /*if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //mListener = null;
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnListFragmentInteractionListener {
        // TODO: Update argument type and name
        void onListFragmentInteraction(ForecastInfo item);
    }
}
