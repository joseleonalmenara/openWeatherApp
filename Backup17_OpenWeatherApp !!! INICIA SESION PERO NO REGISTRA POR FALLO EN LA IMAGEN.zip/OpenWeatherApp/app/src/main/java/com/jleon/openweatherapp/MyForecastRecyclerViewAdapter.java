package com.jleon.openweatherapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.jleon.openweatherapp.model.Forecast.ForecastItem;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by jleon on 2/03/18.
 */

public class MyForecastRecyclerViewAdapter extends RecyclerView.Adapter<MyForecastRecyclerViewAdapter.ViewHolder> {

    private Context ctx;
    private final List<ForecastItem> mValues;
    //private final OnListFragmentInteractionListener mListener;

    public MyForecastRecyclerViewAdapter(Context context, List<ForecastItem> items) {
        ctx = context;
        mValues = items;
        //mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_forecast, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);

        holder.textViewTempMax.setText(String.valueOf(holder.mItem.getMain().getTempMax() + "º"));
        holder.textViewTempMin.setText(String.valueOf(holder.mItem.getMain().getTempMin() + "º"));
        holder.textViewPresion.setText("Presión: " + String.valueOf(holder.mItem.getMain().getPressure()));
        holder.textViewHumedad.setText("Humedad: " + String.valueOf(holder.mItem.getMain().getHumidity()));
        holder.textViewFecha.setText(holder.mItem.getDtTxt());

        Picasso.with(ctx)
                .load("http://openweathermap.org/img/w/"
                        + holder.mItem.getWeather().get(0).getIcon()
                        + ".png")
                .resize(800, 800)
                .centerCrop()
                .into(holder.imageViewIcon);


    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;

        public final ImageView imageViewIcon;
        public final TextView textViewTempMax;
        public final TextView textViewTempMin;
        public final TextView textViewPresion;
        public final TextView textViewHumedad;
        public final TextView textViewFecha;

        public ForecastItem mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            imageViewIcon = view.findViewById(R.id.imageViewForecastIcon);
            textViewTempMax = view.findViewById(R.id.textViewForecastTempMax);
            textViewTempMin = view.findViewById(R.id.textViewForecastTempMin);
            textViewPresion = view.findViewById(R.id.textViewForecastPresion);
            textViewHumedad = view.findViewById(R.id.textViewForecastHumedad);
            textViewFecha = view.findViewById(R.id.textViewForecastFecha);

        }

        /*
        @Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }
        */
    }
}
