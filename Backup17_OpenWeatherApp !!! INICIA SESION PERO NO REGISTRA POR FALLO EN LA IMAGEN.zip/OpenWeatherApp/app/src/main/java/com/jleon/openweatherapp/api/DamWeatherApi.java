package com.jleon.openweatherapp.api;

import com.jleon.openweatherapp.ResponseAuth;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

/**
 * Created by jleon on 03/03/2018.
 */

public interface DamWeatherApi {
    @Multipart
    @POST("/api/v1/auth/register")
    Call<ResponseAuth> doRegister(@Part("email") String email,
                                  @Part("password") String password,
                                  @Part("displayName") String displayName,
                                  @Part("photo") String photo);

    @FormUrlEncoded
    @POST("/api/v1/auth/login")
    Call<ResponseAuth> doLogin(@Field("email") String email,
                               @Field("password") String password);
}
