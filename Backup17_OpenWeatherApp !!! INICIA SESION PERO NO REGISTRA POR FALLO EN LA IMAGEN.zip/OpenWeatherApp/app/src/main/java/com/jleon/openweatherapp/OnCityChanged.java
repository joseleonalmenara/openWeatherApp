package com.jleon.openweatherapp;

/**
 * Created by jleon on 03/03/2018.
 */

public interface OnCityChanged {
        void actualizaCoordenadas(Double lat, Double lng);
    }

